{
"token": "eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiUEJFUzItSFMyNTYrQTEyOEtXIiwicDJjIjozMjg4LCJwMnMiOiIyclB1dUl2RGlZN2VmS01PTEswanNBIn0.ibJ4dPbKJ1mW8_TvEK6gSWdX9ao2jm-GtCgptQE-o_1stQP5Lu594A.RQiFkHfW-Do7pkEfhJVF-Q.zbwKLJvRKQCe_PIwursaBDqxZn4-El98r4Lhi2ociSWVOmUqscNle1buyhtGt9gv7--is-h571d6W998TT76rgYXSc4kdS9Ox65fhQPtF_qaAMA0liXPQcE7NngXLJCeY0MwR4sh76mzfxReE1bCpr9xnrmLbCR7YzAgFcW0kUApYPw9L3BSL7GBylfgryI7MubNlzIFNdLV-8oCwKtQ-Q.yoBb2R7-tLkoQrLrnF_dEg"
}

[
    {
        "website_id": 2,
        "website_uuid": "17af69d0-4668-439e-944a-2ed2be970114",
        "user_id": 1,
        "name": "ekswhyz",
        "domain": "ekswhyz.vercel.app",
        "share_id": "lK2xpnDs",
        "created_at": "2022-02-15T15:56:55.485Z"
    }
]
