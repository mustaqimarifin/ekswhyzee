//import { CommentType } from 'threads/utils/types';
import { NextApiRequest, NextApiResponse } from 'next';

import { definitions } from '@/comments/types/supabase';
import supabase from '@/comments/utils/supaPublic';
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const slug = req.query.slug as string;

  if (req.method === 'GET') {
    const { data: comments, error } = await supabase
      .from<definitions['comments_thread_with_user_vote']>(
        'comments_thread_with_user_vote'
      )
      .select('*')
      .filter('slug', 'eq', slug)
      .order('createdAt', { ascending: false });

    if (comments) {
      return res.status(200).json(comments);
    }
    if (error)
      return res.status(400).json({
        message: 'Unsupported Request',
      });
  }
  const session = supabase.auth.session();
  const { text, parentId, cnp_id } = req.body;
  const newComment = {
    authorId: session?.user?.id,
    text,
    parentId: parentId || null,
    cnp_id: cnp_id || null,
    slug,
  };

  if (req.method === 'POST') {
    const { data: comment, error } = await supabase
      .from<definitions['comments_thread_with_user_vote']>(
        'comments_thread_with_user_vote'
      )
      .insert([newComment])
      .single();

    if (comment) {
      return res.status(200).json(comment);
    }
    if (error)
      return res.status(400).json({
        message: `Comment has wandered into the abyss`,
      });
  }
}
